def saludo():
    print("Hey")